package com.ciclo3.reto.retog5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Retog5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
