package com.ciclo3.reto.retog5.repositorio;

import com.ciclo3.reto.retog5.entidad.Room;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoomRepository extends JpaRepository<Room, Long> {
}
