package com.ciclo3.reto.retog5.repositorio;

import com.ciclo3.reto.retog5.entidad.Score;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ScoreRepository extends JpaRepository<Score,Long> {
}
