package com.ciclo3.reto.retog5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Retog5Application {

    public static void main(String[] args) {
        SpringApplication.run(Retog5Application.class, args);
    }

}
